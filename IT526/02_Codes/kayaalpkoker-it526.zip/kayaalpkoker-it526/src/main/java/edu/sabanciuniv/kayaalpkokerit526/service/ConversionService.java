package edu.sabanciuniv.kayaalpkokerit526.service;

import edu.sabanciuniv.kayaalpkokerit526.model.ConversionRequest;
import edu.sabanciuniv.kayaalpkokerit526.model.CurrencyEntity;
import edu.sabanciuniv.kayaalpkokerit526.repository.ConversionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ConversionService {

    private final ConversionRepository conversionRepository;

    public ConversionRequest getConversion(String source, String target) {
        return new ConversionRequest();

    }
}
