package edu.sabanciuniv.kayaalpkokerit526.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class CurrencyEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String source;
    private String target;
    private double rate;


    public CurrencyEntity(String source, String target, double rate) {
        this.source = source;
        this.target = target;
        this.rate = rate;
    }

    public CurrencyEntity(String source, String target) {
        this.source = source;
        this.target = target;
    }

}


