package edu.sabanciuniv.kayaalpkokerit526.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class ConversionResponse {

    private String sourceCurrency;
    private String targetCurrency;
    private double sourceAmount;
    private double targetAmount;
    private LocalDate conversionDate;

}
