package edu.sabanciuniv.kayaalpkokerit526.repository;

import edu.sabanciuniv.kayaalpkokerit526.model.CurrencyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConversionRepository extends JpaRepository<CurrencyEntity, Long> {

}
