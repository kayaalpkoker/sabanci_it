package edu.sabanciuniv.kayaalpkokerit526.initialize;

import edu.sabanciuniv.kayaalpkokerit526.model.CurrencyEntity;
import edu.sabanciuniv.kayaalpkokerit526.model.CurrencyModel;
import edu.sabanciuniv.kayaalpkokerit526.model.CurrencySubModel;
import edu.sabanciuniv.kayaalpkokerit526.model.Rate;
import edu.sabanciuniv.kayaalpkokerit526.repository.CurrencyRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


@Component
@RequiredArgsConstructor
@Slf4j
public class TestDataInitializer implements CommandLineRunner {

    private final RestTemplate restTemplate;
    private final CurrencyRepository currencyRepository;

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        if (currencyRepository.count() == 0) {

            log.info("-----DATA MIGRATION STARTED-----");

            CurrencyModel currencyModel = restTemplate.getForObject("https://mocki.io/v1/1e26abb9-d48e-42b9-995d-54cddecfbae2", CurrencyModel.class);
            log.warn(String.valueOf(currencyModel));

            for (CurrencySubModel currencySubModel: currencyModel.getCurrencies()) {
                for(Rate rate: currencySubModel.getRates()){
                    currencyRepository.save(new CurrencyEntity(currencySubModel.getSource(),rate.getTarget(),rate.getRate()));
                }
            }
            log.info("-----DATA MIGRATION SUCCESSFUL-----");

        }
    }



}
