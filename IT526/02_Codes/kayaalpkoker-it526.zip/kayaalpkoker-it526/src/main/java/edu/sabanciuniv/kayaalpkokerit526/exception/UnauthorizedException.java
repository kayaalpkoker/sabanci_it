package edu.sabanciuniv.kayaalpkokerit526.exception;

public class UnauthorizedException extends RuntimeException {
    public UnauthorizedException(String msg) {
        super(msg);
    }
}

