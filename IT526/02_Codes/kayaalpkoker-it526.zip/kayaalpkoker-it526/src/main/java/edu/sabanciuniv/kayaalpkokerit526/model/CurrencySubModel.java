package edu.sabanciuniv.kayaalpkokerit526.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class CurrencySubModel {
    private String source;
    private List<Rate> rates = new ArrayList<>();
}