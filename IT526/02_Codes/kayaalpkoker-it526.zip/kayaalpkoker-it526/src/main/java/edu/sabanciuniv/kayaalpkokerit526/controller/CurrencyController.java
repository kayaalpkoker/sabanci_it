package edu.sabanciuniv.kayaalpkokerit526.controller;

import edu.sabanciuniv.kayaalpkokerit526.model.CurrencyEntity;
import edu.sabanciuniv.kayaalpkokerit526.service.CurrencyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/rate")
@RequiredArgsConstructor
@Slf4j
public class CurrencyController {

    private final CurrencyService currencyService;

    @GetMapping("/{source}/{target}")
    public CurrencyEntity getRate(@PathVariable String source, @PathVariable String target) {
        log.info("rate request: source=" + source +" target="+target);
        return currencyService.getRate(source, target);
    }

    @GetMapping("/all")
    public List<CurrencyEntity> getRates() {
        return currencyService.getAllRates();
    }


}
