package edu.sabanciuniv.kayaalpkokerit526.repository;

import edu.sabanciuniv.kayaalpkokerit526.model.CurrencyEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CurrencyRepository extends JpaRepository<CurrencyEntity, Long> {

    //@Query("select o from Order o where o.orderId =:orderId")
    CurrencyEntity findRatesBySourceAndTarget(String source, String target);
}
