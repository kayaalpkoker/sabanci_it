package edu.sabanciuniv.kayaalpkokerit526.controller;

import edu.sabanciuniv.kayaalpkokerit526.model.ConversionRequest;
import edu.sabanciuniv.kayaalpkokerit526.model.CurrencyEntity;
import edu.sabanciuniv.kayaalpkokerit526.service.ConversionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/convert")
@RequiredArgsConstructor
@Slf4j
public class ConversionController {

    private final ConversionService conversionService;

    @GetMapping("/{source}/{target}")
    public ConversionRequest getRate(@PathVariable String source, @PathVariable String target) {
        log.info("conversion request: source=" + source +" target="+target);
        return conversionService.getConversion(source, target);
    }

}
