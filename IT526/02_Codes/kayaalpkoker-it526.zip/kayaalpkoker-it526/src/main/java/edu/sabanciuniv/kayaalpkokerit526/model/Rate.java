package edu.sabanciuniv.kayaalpkokerit526.model;

import lombok.Data;

@Data
public class Rate {
    private String target; private double rate;
}