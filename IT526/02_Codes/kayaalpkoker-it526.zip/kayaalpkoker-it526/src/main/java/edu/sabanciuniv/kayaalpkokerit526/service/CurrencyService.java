package edu.sabanciuniv.kayaalpkokerit526.service;

import edu.sabanciuniv.kayaalpkokerit526.model.CurrencyEntity;
import edu.sabanciuniv.kayaalpkokerit526.repository.CurrencyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CurrencyService {

    private final CurrencyRepository currencyRepository;

    public CurrencyEntity getRate(String source, String target) {
        return currencyRepository.findRatesBySourceAndTarget(source, target);
                //.orElseThrow(() -> new RuntimeException("Book not found!"));
    }

    public List<CurrencyEntity> getAllRates() {
        return currencyRepository.findAll();
    }



}
