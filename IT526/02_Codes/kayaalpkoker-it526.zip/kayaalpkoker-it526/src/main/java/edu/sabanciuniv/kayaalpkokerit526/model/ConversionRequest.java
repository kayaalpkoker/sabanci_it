package edu.sabanciuniv.kayaalpkokerit526.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ConversionRequest {

    private String sourceCurrency;
    private String targetCurrency;
    private double sourceAmount;

}
