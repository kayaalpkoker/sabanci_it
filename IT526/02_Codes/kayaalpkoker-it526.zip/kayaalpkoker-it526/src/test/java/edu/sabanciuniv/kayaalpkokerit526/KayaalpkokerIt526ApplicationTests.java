package edu.sabanciuniv.kayaalpkokerit526;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KayaalpkokerIt526ApplicationTests {

    @Test
    void contextLoads() {
    }

}
